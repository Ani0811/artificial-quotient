(()=>{var a={};a.id=746,a.ids=[746],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},1932:a=>{"use strict";a.exports=require("url")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},8128:a=>{"use strict";a.exports=require("next/dist/server/runtime-reacts.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:a=>{"use strict";a.exports=require("dns")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:a=>{"use strict";a.exports=require("os")},27013:(a,b,c)=>{"use strict";c.d(b,{E:()=>e});let d=new Map;function e(a,b=5,c=6e4){let f=a.headers.get("x-forwarded-for"),g=a.headers.get("x-real-ip"),h=(f?f.split(",")[0].trim():g)||"127.0.0.1",i=Date.now(),j=`${h}`,k=d.get(j);if(k||(k={timestamps:[]},d.set(j,k)),k.timestamps=k.timestamps.filter(a=>i-a<c),k.timestamps.length>=b)return{success:!1,limit:b,remaining:0,resetMs:Math.max(0,c-(i-k.timestamps[0]))};k.timestamps.push(i);let l=Math.max(0,b-k.timestamps.length);return{success:!0,limit:b,remaining:l,resetMs:c}}"u">typeof setInterval&&setInterval(()=>{let a=Date.now();for(let[b,c]of d.entries())c.timestamps=c.timestamps.filter(b=>a-b<6e5),0===c.timestamps.length&&d.delete(b)},3e5)},27910:a=>{"use strict";a.exports=require("stream")},28354:a=>{"use strict";a.exports=require("util")},28573:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>z,patchFetch:()=>y,routeModule:()=>u,serverHooks:()=>x,workAsyncStorage:()=>v,workUnitAsyncStorage:()=>w});var d=c(19225),e=c(84006),f=c(8317),g=c(99373),h=c(34775),i=c(24235),j=c(261),k=c(54365),l=c(90771),m=c(73461),n=c(67798),o=c(92280),p=c(62018),q=c(45696),r=c(47929),s=c(86439),t=c(37527);let u=new d.AppRouteRouteModule({definition:{kind:e.RouteKind.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\GitHub\\artificial-quotient\\src\\app\\api\\contact\\route.ts",nextConfigOutput:"",userland:()=>c(76275),...{}}),{workAsyncStorage:v,workUnitAsyncStorage:w,serverHooks:x}=u;function y(){return(0,f.patchFetch)({workAsyncStorage:v,workUnitAsyncStorage:w})}async function z(a,b,c){c.requestMeta&&(0,g.setRequestMeta)(a,c.requestMeta),u.isDev&&(0,g.addRequestMeta)(a,"devRequestTimingInternalsEnd",process.hrtime.bigint());let d="/api/contact/route";"/index"===d&&(d="/");let f=await u.prepare(a,b,{srcPage:d,multiZoneDraftMode:!1});if(!f)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:v,deploymentId:w,params:x,nextConfig:y,parsedUrl:z,isDraftMode:A,prerenderManifest:B,routerServerContext:C,isOnDemandRevalidate:D,revalidateOnlyGenerated:E,resolvedPathname:F,clientReferenceManifest:G,serverActionsManifest:H}=f,I=(0,j.normalizeAppPath)(d),J=!!(B.dynamicRoutes[I]||B.routes[F]),K=async()=>((null==C?void 0:C.render404)?await C.render404(a,b,z,!1):b.end("This page could not be found"),null);if(J&&!A){let a=!!B.routes[F],b=B.dynamicRoutes[I];if(b&&!1===b.fallback&&!a){if(y.adapterPath)return await K();throw new s.NoFallbackError}}let L=null;!J||u.isDev||A||(L="/index"===(L=F)?"/":L);let M=!0===u.isDev||!J,N=J&&!M;H&&G&&(0,i.setManifestsSingleton)({page:d,clientReferenceManifest:G,serverActionsManifest:H});let O=a.method||"GET",P=(0,h.getTracer)(),Q=P.getActiveScopeSpan(),R=!!(null==C?void 0:C.isWrappedByNextServer),S=!!(0,g.getRequestMeta)(a,"minimalMode"),T=(0,g.getRequestMeta)(a,"incrementalCache")||await u.getIncrementalCache(a,y,B,S);null==T||T.resetRequestCache(),globalThis.__incrementalCache=T;let U={params:x,previewProps:B.preview,renderOpts:{experimental:{authInterrupts:!!y.experimental.authInterrupts,useCacheTimeout:y.experimental.useCacheTimeout},cacheComponents:!!y.cacheComponents,validationLevel:y.experimental.instantInsights.validationLevel,supportsDynamicResponse:M,incrementalCache:T,hmrRefreshHash:(0,g.getRequestMeta)(a,"hmrRefreshHash"),cacheLifeProfiles:y.cacheLife,staticPageGenerationTimeout:y.staticPageGenerationTimeout,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d,e)=>u.onRequestError(a,b,d,e,C)},sharedContext:{buildId:v,deploymentId:w}},V=new k.NodeNextRequest(a),W=new k.NodeNextResponse(b),X=l.NextRequestAdapter.fromNodeNextRequest(V,(0,l.signalFromNodeResponse)(b)),Y=async({previousCacheEntry:e})=>{try{if(!S&&D&&E&&!e)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let d=await u.handle(X,U);a.fetchMetrics=U.renderOpts.fetchMetrics;let f=U.renderOpts.pendingWaitUntil;f&&c.waitUntil&&(c.waitUntil(f),f=void 0);let g=U.renderOpts.collectedTags;if(!J)return await (0,o.I)(V,W,d,f),null;{let a=await d.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(d.headers);g&&(b[r.NEXT_CACHE_TAGS_HEADER]=g),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==U.renderOpts.collectedRevalidate&&!(U.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&U.renderOpts.collectedRevalidate,e=void 0===U.renderOpts.collectedExpire||U.renderOpts.collectedExpire>=r.INFINITE_CACHE?!1!==c&&c>0?y.expireTime:void 0:U.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:d.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:e}}}}catch(b){throw(null==e?void 0:e.isStale)&&await u.onRequestError(a,b,{routerKind:"App Router",routePath:d,routeType:"route",revalidateReason:(0,n.getRevalidateReason)({isStaticGeneration:N,isOnDemandRevalidate:D})},!1,C),b}},Z=async(d,f)=>{try{var g,i;let d=await u.handleResponse({req:a,nextConfig:y,cacheKey:L,routeKind:e.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:B,isRoutePPREnabled:!1,isOnDemandRevalidate:D,revalidateOnlyGenerated:E,responseGenerator:Y,waitUntil:c.waitUntil,isMinimalMode:S});if(!J)return;if((null==d||null==(g=d.value)?void 0:g.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(i=d.value)?void 0:i.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});S||b.setHeader("x-nextjs-cache",D?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),A&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let f=(0,p.fromNodeOutgoingHttpHeaders)(d.value.headers);S&&J||f.delete(r.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||b.getHeader("Cache-Control")||f.get("Cache-Control")||f.set("Cache-Control",(0,q.getCacheControlHeader)(d.cacheControl)),await (0,o.I)(V,W,new Response(d.value.body,{headers:f,status:d.value.status||200}));return}catch(b){if(b instanceof s.NoFallbackError||await u.onRequestError(a,b,{routerKind:"App Router",routePath:I,routeType:"route",revalidateReason:(0,n.getRevalidateReason)({isStaticGeneration:N,isOnDemandRevalidate:D})},!1,C),J)throw b;await (0,o.I)(V,W,new Response(null,{status:500}));return}finally{(()=>{if(!d)return;let a=b.statusCode;d.setAttributes({"http.status_code":a,"next.rsc":!1}),a&&a>=500&&(d.setStatus({code:h.SpanStatusCode.ERROR}),d.setAttribute("error.type",a.toString()));let c=P.getRootSpanAttributes();if(!c)return;if(c.get("next.span_type")!==m.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${c.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=c.get("next.route")||I,g=`${O} ${e}`;d.setAttributes({"next.route":e,"http.route":e,"next.span_name":g}),d.updateName(g),f&&f!==d&&(f.setAttribute("http.route",e),f.updateName(g))})()}};if(R&&Q)await Z(Q,void 0);else{let b=P.getActiveScopeSpan();await P.withPropagatedContext(a.headers,()=>P.trace(m.BaseServerSpan.handleRequest,{spanName:`${O} ${d}`,kind:h.SpanKind.SERVER,attributes:{"http.method":O,"http.target":a.url}},a=>Z(a,b)),void 0,!R)}}},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},34631:a=>{"use strict";a.exports=require("tls")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{"use strict";a.exports=require("crypto")},55591:a=>{"use strict";a.exports=require("https")},62751:(a,b,c)=>{"use strict";c.d(b,{JK:()=>j,hY:()=>i});var d=c(35924),e=c(33873),f=c.n(e),g=c(29021),h=c.n(g);async function i({toEmail:a,subject:b,htmlContent:c,textContent:d,replyTo:e,senderNameOverride:f}){let g=function(){let a=[],b="Artificial Quotient Security",c=process.env.BREVO_SENDER_EMAIL||process.env.SMTP_USER||"anirudha.basuthakur@gmail.com";if(process.env.BREVO_API_KEYS){let d=process.env.BREVO_API_KEYS.split(",").map(a=>a.trim()).filter(Boolean),e=process.env.BREVO_SENDER_EMAILS?process.env.BREVO_SENDER_EMAILS.split(",").map(a=>a.trim()).filter(Boolean):[];d.forEach((d,f)=>{a.push({apiKey:d,senderEmail:e[f]||c,senderName:b})})}for(let d=1;d<=10;d++){let e=process.env[`BREVO_API_KEY_${d}`];if(e&&e.trim()){let f=process.env[`BREVO_SENDER_EMAIL_${d}`]||c;a.some(a=>a.apiKey===e.trim())||a.push({apiKey:e.trim(),senderEmail:f.trim(),senderName:b})}}if(process.env.BREVO_API_KEY&&process.env.BREVO_API_KEY.trim()){let d=process.env.BREVO_API_KEY.trim();a.some(a=>a.apiKey===d)||a.push({apiKey:d,senderEmail:c,senderName:b})}return a}();if(0===g.length)return!1;for(let h=0;h<g.length;h++){let i=g[h],j=i.apiKey.length>12?`${i.apiKey.substring(0,8)}...${i.apiKey.slice(-4)}`:i.apiKey,k=`Brevo Key #${h+1} (${j}, Sender: ${i.senderEmail})`;try{let g={sender:{name:f||i.senderName,email:i.senderEmail},to:[{email:a}],subject:b,htmlContent:c};d&&(g.textContent=d),e&&(g.replyTo=e);let h=await fetch("https://api.brevo.com/v3/smtp/email",{method:"POST",headers:{"api-key":i.apiKey,accept:"application/json","content-type":"application/json"},body:JSON.stringify(g)});if(h.ok)return console.log(`Email sent successfully via ${k} to: ${a}`),!0;let j=await h.json().catch(()=>({}));console.warn(`Brevo API error on ${k} (HTTP ${h.status}):`,j,"-> Failover to next key...")}catch(a){console.warn(`Brevo fetch exception on ${k}:`,a,"-> Failover to next key...")}}return console.warn("All configured Brevo API keys failed. Falling back to SMTP..."),!1}async function j(a,b){let c=process.env.SMTP_USER||"anirudha.basuthakur@gmail.com",e="Artificial Quotient Security",g="Your Artificial Quotient Verification Code",j=f().join(process.cwd(),"public","logo","logo-removebg-preview.png");try{h().existsSync(j)&&h().readFileSync(j).toString("base64")}catch{}let k=`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>2-Step Verification Code</title>
    </head>
    <body style="margin: 0; padding: 0; background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased;">
      <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #0b0f19; padding: 40px 10px;">
        <tr>
          <td align="center">
            <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #111827; border: 1px solid #1f2937; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);">
              <tr>
                <td style="height: 4px; background: linear-gradient(90deg, #3b82f6 0%, #8b5cf6 50%, #10b981 100%);"></td>
              </tr>
              <tr>
                <td style="padding: 32px 32px 24px 32px; text-align: center;">
                  <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td align="center">
                        <img src="https://artificial-quotient.com/logo.jpeg" width="56" height="56" alt="Artificial Quotient Logo" style="width: 56px; height: 56px; border-radius: 14px; margin-bottom: 14px; border: 1px solid #374151; display: block;" />
                        <div style="display: inline-block; padding: 6px 14px; background-color: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.25); border-radius: 20px; margin-bottom: 16px;">
                          <span style="color: #60a5fa; font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase;">
                            Security Gateway
                          </span>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td align="center">
                        <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">
                          Artificial<span style="color: #3b82f6;">Quotient</span>
                        </h1>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

              <tr>
                <td style="padding: 0 32px 32px 32px; text-align: center;">
                  <h2 style="margin: 0 0 12px 0; color: #f3f4f6; font-size: 18px; font-weight: 600;">
                    Two-Step Verification Code
                  </h2>
                  <p style="margin: 0 0 28px 0; color: #9ca3af; font-size: 14px; line-height: 1.6;">
                    You requested to sign in to the Artificial Quotient Admin Portal. Enter the 6-digit verification code below to authorize your session:
                  </p>

                  <div style="background: linear-gradient(180deg, #1f2937 0%, #111827 100%); border: 1px solid #374151; border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center;">
                    <div style="font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 800; color: #38bdf8; letter-spacing: 8px; text-indent: 8px; margin: 0;">
                      ${b}
                    </div>
                    <div style="margin-top: 12px; font-size: 12px; color: #f59e0b; font-weight: 600;">
                      Code expires in 5 minutes
                    </div>
                  </div>

                  <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 10px; padding: 14px 16px;">
                    <tr>
                      <td style="color: #f87171; font-size: 12px; line-height: 1.5; text-align: left;">
                        <strong>Security Notice:</strong> If you did not request this login attempt, please ignore this email or contact a System Administrator immediately.
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

              <tr>
                <td style="background-color: #0b0f19; padding: 20px 32px; text-align: center; border-top: 1px solid #1f2937;">
                  <p style="margin: 0; color: #6b7280; font-size: 12px; line-height: 1.5;">
                    Artificial Quotient Automation Systems • Automated Security Gateway
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;if(await i({toEmail:a,subject:g,htmlContent:k,senderNameOverride:e}))return!0;try{let b=d.createTransport({host:process.env.SMTP_HOST||"smtp.gmail.com",port:Number(process.env.SMTP_PORT)||587,secure:!1,auth:{user:c,pass:process.env.SMTP_PASS||""},tls:{rejectUnauthorized:!1}}),f={from:`"${e}" <${c}>`,to:a,subject:g,attachments:[{filename:"logo.jpeg",path:j,cid:"aqlogo@artificialquotient"}],html:k},h=await b.sendMail(f);return console.log("2FA email sent via Nodemailer SMTP: %s",h.messageId),!0}catch(a){return console.error("Error sending 2FA email via Nodemailer SMTP:",a),!1}}},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:a=>{"use strict";a.exports=require("zlib")},76275:(a,b,c)=>{"use strict";c.r(b),c.d(b,{OPTIONS:()=>i,POST:()=>j,dynamic:()=>h});var d=c(23211),e=c(35924),f=c(27013),g=c(62751);let h="force-dynamic";async function i(){return new d.NextResponse(null,{status:200,headers:{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization, X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Date, X-Api-Version"}})}async function j(a){let b=(0,f.E)(a,5,6e4);if(!b.success)return d.NextResponse.json({success:!1,message:`Too many contact requests. Please wait ${Math.ceil(b.resetMs/1e3)} seconds before sending another message.`},{status:429});try{let{name:b,email:c,inquiryType:f,subject:h,message:i}=await a.json();if(!b||!c||!i)return d.NextResponse.json({success:!1,message:"Name, email, and message are required."},{status:400});let j=process.env.CONTACT_RECEIVER_EMAIL||"artificialquotient01@gmail.com",k=`Inquiry: ${f} - ${h||"New Message"}`,l=function(a){let{name:b,email:c,inquiryType:d,subject:e,message:f}=a;return`
NEW INQUIRY — ARTIFICIAL QUOTIENT™
==================================================

From: ${b} (${c})
Category: ${d}
Subject: ${e||"No Subject"}

--------------------------------------------------
MESSAGE:
--------------------------------------------------
${f}

==================================================
Reply directly to ${b}: mailto:${c}
\xa9 ${new Date().getFullYear()} Artificial Quotient™. All rights reserved.
  `.trim()}({name:b,email:c,inquiryType:f,subject:h,message:i}),m=function(a){let{name:b,email:c,inquiryType:d,subject:e,message:f}=a,g=b?b.trim().charAt(0).toUpperCase():"A",h=encodeURIComponent(`Re: ${e||d||"Artificial Quotient Inquiry"}`);return`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Sponsorship Inquiry — Artificial Quotient™</title>
</head>
<body style="margin: 0; padding: 0; background-color: #061612; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; color: #ecfdf5;">
  
  <!-- Outer Container -->
  <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #061612; padding: 40px 16px;">
    <tr>
      <td align="center">
        
        <!-- Main Card -->
        <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #0c201a; border: 1px solid #16382e; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.7);">
          
          <!-- Top Emerald Gradient Accent Bar -->
          <tr>
            <td style="height: 4px; background: linear-gradient(90deg, #10b981 0%, #14b8a6 50%, #06b6d4 100%);"></td>
          </tr>

          <!-- Brand Header with Official Logo & Trademark -->
          <tr>
            <td style="padding: 24px 32px; border-bottom: 1px solid #16382e;">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left" valign="middle">
                    <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td valign="middle" style="padding-right: 12px;">
                          <img src="https://artificial-quotient.com/logo/logo-removebg-preview.png" alt="Artificial Quotient Logo" width="40" height="40" style="width: 40px; height: 40px; border-radius: 10px; border: 1px solid rgba(16, 185, 129, 0.4); display: block; object-fit: cover;" />
                        </td>
                        <td valign="middle">
                          <div style="font-size: 20px; font-weight: 800; color: #ffffff; letter-spacing: -0.02em; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.2;">
                            Artificial<span style="color: #10b981;">Quotient</span><sup style="font-size: 10px; color: #10b981; font-weight: 800; margin-left: 2px;">™</sup>
                          </div>
                          <div style="font-size: 11px; color: #6ee7b7; font-weight: 600; letter-spacing: 0.02em;">
                            Official Sponsorship Portal
                          </div>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td align="right" valign="middle">
                    <span style="display: inline-block; padding: 6px 14px; background-color: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); color: #6ee7b7; font-size: 11px; font-weight: 700; border-radius: 100px; text-transform: uppercase; letter-spacing: 0.06em;">
                      ⚡ Incoming Inquiry
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Sender Profile Section -->
          <tr>
            <td style="padding: 28px 32px 12px 32px;">
              <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #102922; border: 1px solid #16382e; border-radius: 14px; padding: 20px;">
                <tr>
                  <td width="52" valign="middle" style="padding-right: 16px;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #10b981, #059669); color: #ffffff; font-weight: 800; font-size: 20px; border-radius: 14px; text-align: center; line-height: 48px; box-shadow: 0 4px 14px rgba(16, 185, 129, 0.35);">
                      ${g}
                    </div>
                  </td>
                  <td valign="middle">
                    <div style="font-size: 18px; font-weight: 700; color: #ffffff; margin-bottom: 3px;">
                      ${b}
                    </div>
                    <div style="font-size: 14px;">
                      <a href="mailto:${c}" style="color: #34d399; text-decoration: none; font-weight: 600;">
                        ${c}
                      </a>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Category & Subject Details -->
          <tr>
            <td style="padding: 12px 32px 20px 32px;">
              <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #102922; border: 1px solid #16382e; border-radius: 14px; padding: 18px 20px;">
                <tr>
                  <td style="padding-bottom: 14px; border-bottom: 1px solid #16382e;">
                    <span style="font-size: 11px; font-weight: 700; color: #6ee7b7; text-transform: uppercase; letter-spacing: 0.08em; display: block; margin-bottom: 6px;">Inquiry Category</span>
                    <span style="display: inline-block; padding: 4px 12px; background-color: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); color: #a7f3d0; font-size: 12px; font-weight: 700; border-radius: 8px;">
                      ${d}
                    </span>
                  </td>
                </tr>
                <tr>
                  <td style="padding-top: 14px;">
                    <span style="font-size: 11px; font-weight: 700; color: #6ee7b7; text-transform: uppercase; letter-spacing: 0.08em; display: block; margin-bottom: 6px;">Subject</span>
                    <span style="font-size: 15px; font-weight: 700; color: #ffffff;">
                      ${e||"No Subject Provided"}
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Message Body -->
          <tr>
            <td style="padding: 0 32px 28px 32px;">
              <div style="background-color: #102922; border: 1px solid #16382e; border-left: 4px solid #10b981; border-radius: 14px; padding: 22px 24px;">
                <div style="font-size: 11px; font-weight: 800; color: #34d399; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 12px;">
                  Message Content
                </div>
                <div style="font-size: 15px; line-height: 1.7; color: #e2e8f0; white-space: pre-wrap; font-weight: 400;">
                  ${f}
                </div>
              </div>
            </td>
          </tr>

          <!-- Direct Reply Button -->
          <tr>
            <td style="padding: 0 32px 32px 32px;" align="center">
              <a href="mailto:${c}?subject=${h}" style="display: block; width: 100%; box-sizing: border-box; padding: 15px 24px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #ffffff; font-weight: 800; font-size: 15px; text-align: center; text-decoration: none; border-radius: 12px; box-shadow: 0 6px 20px rgba(16, 185, 129, 0.35);">
                ✉️ Reply directly to ${b}
              </a>
            </td>
          </tr>

          <!-- Footer with Trademark & Legal Notice -->
          <tr>
            <td style="padding: 24px 32px; background-color: #061612; border-top: 1px solid #16382e; text-align: center;">
              <div style="font-size: 12px; color: #6ee7b7; font-weight: 600; margin-bottom: 6px;">
                \xa9 ${new Date().getFullYear()} <strong style="color: #ffffff;">Artificial Quotient™</strong>. All rights reserved.
              </div>
              <div style="font-size: 11px; color: #34d399; opacity: 0.75; line-height: 1.5;">
                Artificial Quotient™ is a trademark of Artificial Quotient Media Hub.<br />
                🔒 Transmitted via SSL Encrypted Automated Gateway
              </div>
            </td>
          </tr>

        </table>

      </td>
    </tr>
  </table>

</body>
</html>
  `.trim()}({name:b,email:c,inquiryType:f,subject:h,message:i});if(await (0,g.hY)({toEmail:j,subject:k,htmlContent:m,textContent:l,replyTo:{email:c,name:b},senderNameOverride:"Artificial Quotient Contact"}))return d.NextResponse.json({success:!0,message:"Your message has been sent successfully."});let n=process.env.SMTP_HOST,o=process.env.SMTP_PORT,p=process.env.SMTP_USER,q=process.env.SMTP_PASS;if(!n||!p||!q)return console.log("\n=================================================="),console.log("\uD83D\uDCE8 [SMTP Config Missing] Logged Email Output:"),console.log(`To: ${j}`),console.log(`Subject: ${k}`),console.log(`Reply-To: ${c}`),console.log("------------------ TEXT BODY ---------------------"),console.log(l.trim()),console.log("==================================================\n"),d.NextResponse.json({success:!0,message:"Email logged to console successfully (Developer Mode fallback)."});let r=q.replace(/\s+/g,""),s=e.createTransport({host:n,port:Number(o)||587,secure:465===Number(o),auth:{user:p,pass:r},tls:{rejectUnauthorized:!1}});return await s.sendMail({from:`"${b} (via AQ)" <${p}>`,to:j,replyTo:c,subject:k,text:l,html:m}),d.NextResponse.json({success:!0,message:"Your message has been sent successfully."})}catch(a){return console.error("Error in contact API route:",a),d.NextResponse.json({success:!1,message:a?.message?`Failed to send email: ${a.message}`:"An internal server error occurred while sending your message."},{status:500})}}},78335:()=>{},79646:a=>{"use strict";a.exports=require("child_process")},81630:a=>{"use strict";a.exports=require("http")},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},91645:a=>{"use strict";a.exports=require("net")},94735:a=>{"use strict";a.exports=require("events")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[445,813,924],()=>b(b.s=28573));module.exports=c})();